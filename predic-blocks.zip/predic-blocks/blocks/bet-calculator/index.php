<?php
// Init the class method that will be called on the server side rendering
\PredicBlocks\Blocks\Templates\BetCalculator::getInstance()->registerDynamicBlock();
