import "./i18n.js";

/**
 * Import blocks
 */
import "./sports-odds-table";
import "./bet-calculator";
