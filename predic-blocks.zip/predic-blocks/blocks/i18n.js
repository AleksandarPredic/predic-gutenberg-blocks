wp.i18n.setLocaleData( { '': {} }, 'predic-blocks' );
