/**
 * Import blocks frontend files
 */
import './bet-calculator/frontend';
import './sports-odds-table/frontend';
